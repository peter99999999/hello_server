package md2all;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import md2all.user.account.Account;
import md2all.user.account.AccountRepository;


/*
 server.port=443
server.ssl.key-store=classpath:214256483460199.pfx
server.ssl.key-store-password=214256483460199
server.ssl.keyStoreType=PKCS12
logging.level.org.hibernate.SQL=debug
spring.datasource.url=jdbc:mysql://127.0.0.1:3306/iot
spring.datasource.username=root
spring.datasource.password=1234
spring.jpa.generate-ddl=true 
spring.jpa.hibernate.ddl-auto=update
 */

@SpringBootApplication
//@EnableJpaRepositories(basePackageClasses=Timer.TimerDataRepository.class)
//@EnableJpaRepositories(basePackageClasses={Timer.TimerDataRepository.class,Timer.TimerData.class})
public class ServerMain extends WebMvcConfigurerAdapter implements CommandLineRunner{
//public class ServerMain implements CommandLineRunner{
	@Autowired			
	AccountRepository accountRepository;			
	

	
	static final boolean SSL = System.getProperty("ssl") != null;
	static final int PORT = Integer.parseInt(System.getProperty("port", "1010"));
	/*public ServerMain() {
		// TODO Auto-generated constructor stub
	}
*/

	public static void main(String[] args) throws Exception {
				
		SpringApplication.run(ServerMain.class, args);
	}
	
	

	
	@Override
	public void run(String... arg0) throws Exception {
	
	
		String  RESOURCE_PUBLIC_PATH="public";
		 File dir;
		 Path photoPath=Paths.get(RESOURCE_PUBLIC_PATH+"/test");
		 dir= new File(photoPath.toUri());
		 if(!dir.exists())  
		 {
				Files.createDirectories(photoPath);
		}
			      

	}
	 
}
